#ifndef MESSENGER_H
#define MESSENGER_H
#include "ufrn_al5d.h"


class messenger
{
public:
    messenger();
    void setParameters(int control, double base, double ombro, double cotovelo, double punho, double garra);
    void connect(void);
    void desconnect(void);
    void send(void);
    void goToHome(void);

private:

    ufrn_al5d arm;
    int serial_fd;
    char *comando;
    double mes_base=500;
    double mes_ombro=1200;
    double mes_cotovelo=1100;
    double mes_punho=500;
    double mes_garra=1300;
    int mes_control =7; // nada=7, base=0,ombro=1, contovelo=2, punho=3, garra=4

};

#endif // MESSENGER_H
