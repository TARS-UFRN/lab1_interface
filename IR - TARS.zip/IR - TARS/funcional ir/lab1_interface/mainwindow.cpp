#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QImage tabuleiro("/home/aluno/Documentos/IR - TARS/funcional ir/lab1_interface/tabuleiro.png");
    QPainter painter(&tabuleiro);
    QPen pen;
    pen.setWidth(90);
    pen.setColor(Qt::red);
    painter.setPen(pen);
    painter.drawEllipse(0,0, 100, 100 );
    painter.end();
    ui->label_tabuleiro->setPixmap(QPixmap::fromImage(tabuleiro));
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::paintEvent(QPaintEvent *e)
{
}

void MainWindow::on_pushButton_home_clicked()
{

    //#define HOME_POS "#0P1500#1P1500#2P1500#3P1500#4P1500T10000" //Instruções no manual, página 5.
    communicator->goToHome();
    window_base=500;
    window_ombro=1200;
    window_cotovelo=1100;
    window_punho=500;
    window_garra=1300;
    window_control =7;
}

void MainWindow::on_dial_Garra_valueChanged(int value)
{

    window_garra=value;
    ui->doubleSpinBox_Garra->setValue(value);
    window_control=4;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();
}

void MainWindow::on_doubleSpinBox_Garra_valueChanged(double arg1)
{
    window_garra=arg1;
    ui->dial_Garra->setValue(arg1);
    window_control=4;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_dial_Punho_valueChanged(int value)
{
    window_punho=value;
    ui->doubleSpinBox_Punho->setValue(value);
    window_control=3;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_doubleSpinBox_Punho_valueChanged(double arg1)
{
    window_punho=arg1;
    ui->dial_Punho->setValue(arg1);
    window_control=3;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                 window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_dial_Cotovelo_valueChanged(int value)
{
    window_cotovelo=value;
    ui->doubleSpinBox_Cotovelo->setValue(value);
    window_control=2;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();
}

void MainWindow::on_doubleSpinBox_Cotovelo_valueChanged(double arg1)
{
    window_cotovelo=arg1;
    ui->dial_Cotovelo->setValue(arg1);
    window_control=2;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();
}

void MainWindow::on_dial_Ombro__valueChanged(int value)
{
    window_ombro=value;
    ui->doubleSpinBox_Ombro->setValue(value);
    window_control=1;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_doubleSpinBox_Ombro_valueChanged(double arg1)
{
    window_ombro=arg1;
    ui->dial_Ombro_->setValue(arg1);
    window_control=1;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_dial_Base_valueChanged(int value)
{
    window_base=value;
    ui->doubleSpinBox_Base->setValue(value);
    window_control=0;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();

}

void MainWindow::on_doubleSpinBox_Base_valueChanged(double arg1)
{
    window_base=arg1;
    ui->dial_Base->setValue(arg1);
    window_control=0;
    communicator->setParameters(window_control, window_base, window_ombro, window_cotovelo,
                                window_punho, window_garra);
    communicator->send();
}

void MainWindow::on_pushButton_connect_clicked()
{

    communicator->connect();
    window_base=500;
    window_ombro=1200;
    window_cotovelo=1100;
    window_punho=500;
    window_garra=1300;
    window_control =7;
}

void MainWindow::on_pushButton_desconnect_clicked()
{
    communicator->desconnect();
}
