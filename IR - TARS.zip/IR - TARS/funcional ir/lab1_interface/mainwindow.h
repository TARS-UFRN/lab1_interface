#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "messenger.h"
#include <QPainter>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    messenger *communicator;

protected:
    void paintEvent(QPaintEvent *e);

private slots:
    void on_pushButton_home_clicked();

    void on_dial_Garra_valueChanged(int value);

    void on_doubleSpinBox_Garra_valueChanged(double arg1);

    void on_dial_Punho_valueChanged(int value);

    void on_doubleSpinBox_Punho_valueChanged(double arg1);

    void on_dial_Cotovelo_valueChanged(int value);

    void on_doubleSpinBox_Cotovelo_valueChanged(double arg1);

    void on_dial_Ombro__valueChanged(int value);

    void on_doubleSpinBox_Ombro_valueChanged(double arg1);

    void on_dial_Base_valueChanged(int value);

    void on_doubleSpinBox_Base_valueChanged(double arg1);

    void on_pushButton_connect_clicked();

    void on_pushButton_desconnect_clicked();

private:
    Ui::MainWindow *ui;

    double window_base=500;
    double window_ombro=1200;
    double window_cotovelo=1100;
    double window_punho=500;
    double window_garra=1300;
    int window_control =7;


};

#endif // MAINWINDOW_H
